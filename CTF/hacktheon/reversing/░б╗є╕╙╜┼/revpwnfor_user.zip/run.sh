#!/bin/bash
socat -t15 -T15 TCP-LISTEN:1337,fork,reuseaddr exec:./revpwn,pty,raw,echo=0