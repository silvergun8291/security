#!/bin/bash
docker build -t revpwn .
docker run -d -p 1337:1337 -it revpwn
