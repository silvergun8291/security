#!/bin/bash

cd /home/ctf/
timeout 25 ./bin
